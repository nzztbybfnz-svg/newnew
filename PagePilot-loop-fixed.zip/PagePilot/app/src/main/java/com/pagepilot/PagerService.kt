package com.pagepilot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max

/**
 * 无障碍服务：
 *  1. 用 TYPE_ACCESSIBILITY_OVERLAY 在所有应用上层显示悬浮翻页条（不需要单独的悬浮窗权限）；
 *  2. 用 dispatchGesture 模拟滑动 / 点击来翻页；
 *  3. 提供定时自动循环翻页。
 */
class PagerService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: PagerService? = null
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var body: LinearLayout? = null
    private var autoBtn: TextView? = null
    private var collapsed = false

    private var auto = false
    private var logic: AutoPagerLogic? = null

    // ---------------------------------------------------------------- 生命周期

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        panel?.post { clampPanel() }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        shutdown()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    private fun shutdown() {
        hidePanel()
        instance = null
    }

    // ---------------------------------------------------------------- 悬浮条

    fun isPanelShown(): Boolean = panel != null

    fun showPanel() {
        if (panel != null) return
        val dm = resources.displayMetrics

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(4), dp(4), dp(4), dp(4))
        val bg = GradientDrawable()
        bg.setColor(Color.argb(205, 28, 28, 30))
        bg.cornerRadius = dp(16).toFloat()
        root.background = bg

        val handle = makeButton("≡") {}
        val prev = makeButton("▲") { manualStep(Step.PREV) }
        val next = makeButton("▼") { manualStep(Step.NEXT) }
        val autoButton = makeButton("自动") { toggleAuto() }
        autoButton.textSize = 14f

        val bodyLayout = LinearLayout(this)
        bodyLayout.orientation = LinearLayout.VERTICAL
        bodyLayout.addView(prev)
        bodyLayout.addView(next)
        bodyLayout.addView(autoButton)

        root.addView(handle)
        root.addView(bodyLayout)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dm.widthPixels - dp(64)
        lp.y = dm.heightPixels / 3

        attachDrag(handle, lp, root)

        try {
            wm.addView(root, lp)
        } catch (e: Exception) {
            return
        }
        panel = root
        panelParams = lp
        body = bodyLayout
        autoBtn = autoButton
        collapsed = false
    }

    fun hidePanel() {
        stopAuto()
        val p = panel ?: return
        try {
            wm.removeView(p)
        } catch (e: Exception) {
            // 视图已经不在窗口里了，忽略
        }
        panel = null
        panelParams = null
        body = null
        autoBtn = null
    }

    private fun makeButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 18f
        t.gravity = Gravity.CENTER
        t.layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        t.setOnClickListener { onClick() }
        return t
    }

    /** 按住最上面的“≡”拖动；轻点则折叠 / 展开。 */
    private fun attachDrag(handle: View, lp: WindowManager.LayoutParams, root: View) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moved = false
        val slop = dp(6).toFloat()

        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        val dm = resources.displayMetrics
                        lp.x = (startX + dx).toInt().coerceIn(0, max(0, dm.widthPixels - root.width))
                        lp.y = (startY + dy).toInt().coerceIn(0, max(0, dm.heightPixels - root.height))
                        try {
                            wm.updateViewLayout(root, lp)
                        } catch (ex: Exception) {
                            // 忽略
                        }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleCollapse()
                    true
                }
                else -> false
            }
        }
    }

    private fun toggleCollapse() {
        collapsed = !collapsed
        body?.visibility = if (collapsed) View.GONE else View.VISIBLE
        panel?.post { clampPanel() }
    }

    private fun clampPanel() {
        val p = panel ?: return
        val lp = panelParams ?: return
        val dm = resources.displayMetrics
        lp.x = lp.x.coerceIn(0, max(0, dm.widthPixels - p.width))
        lp.y = lp.y.coerceIn(0, max(0, dm.heightPixels - p.height))
        try {
            wm.updateViewLayout(p, lp)
        } catch (e: Exception) {
            // 忽略
        }
    }

    // ---------------------------------------------------------------- 翻页

    private fun manualStep(step: Step) {
        if (auto) {
            stopAuto()
            toast("已暂停自动翻页")
        }
        doStep(step) { success ->
            if (!success) toast("手势未执行成功，请检查无障碍服务或翻页方式")
        }
    }

    /** 模拟一次翻页手势；回调明确报告系统是否完成手势。 */
    private fun doStep(step: Step, onDone: (Boolean) -> Unit = {}) {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()

        // NEXT 且没有勾选“方向反了” → 向前的手势；勾选后反过来
        val forward = (step == Step.NEXT) != Prefs.invert(this)

        // 手势尽量避开悬浮条所在的位置，免得点到悬浮条自己
        val lp = panelParams
        val pv = panel
        val avoidX = if (lp != null && pv != null) lp.x + pv.width / 2f else -1f
        val avoidY = if (lp != null && pv != null) lp.y + pv.height / 2f else -1f

        val path = Path()
        val duration: Long
        when (Prefs.gestureMode(this)) {
            Prefs.MODE_HORIZONTAL -> {
                val y = pickLane(h * 0.35f, h * 0.65f, avoidY)
                val from = if (forward) w * 0.8f else w * 0.2f
                val to = if (forward) w * 0.2f else w * 0.8f
                path.moveTo(from, y)
                path.lineTo(to, y)
                duration = 220L
            }
            Prefs.MODE_TAP -> {
                val y = pickLane(h * 0.25f, h * 0.75f, avoidY)
                val x = if (forward) w * 0.85f else w * 0.15f
                path.moveTo(x, y)
                // Stroke 需要明确结束点；极短位移用于生成轻点手势。
                path.lineTo(x + 1f, y + 1f)
                duration = 60L
            }
            else -> {
                val x = pickLane(w * 0.3f, w * 0.7f, avoidX)
                val from = if (forward) h * 0.7f else h * 0.3f
                val to = if (forward) h * 0.3f else h * 0.7f
                path.moveTo(x, from)
                path.lineTo(x, to)
                duration = 220L
            }
        }

        val stroke = GestureDescription.StrokeDescription(path, 0L, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val accepted = dispatchGesture(
            gesture,
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    onDone(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    onDone(false)
                }
            },
            null
        )
        if (!accepted) onDone(false)
    }

    private fun pickLane(a: Float, b: Float, avoid: Float): Float =
        if (abs(a - avoid) >= abs(b - avoid)) a else b

    // ---------------------------------------------------------------- 自动循环

    private val tick = object : Runnable {
        override fun run() {
            if (!auto) return
            val steps = logic?.nextTick() ?: return
            runSteps(steps, 0) {
                if (auto) {
                    handler.postDelayed(this, Prefs.intervalSec(this@PagerService) * 1000L)
                }
            }
        }
    }

    /** 依次执行 steps（退回第一页时会连续执行多次），全部完成后调用 done。 */
    private fun runSteps(steps: List<Step>, i: Int, done: () -> Unit) {
        if (!auto) return
        if (i >= steps.size) {
            done()
            return
        }
        doStep(steps[i]) { success ->
            if (!success) {
                stopAuto()
                toast("自动翻页已停止：系统未完成手势")
                return@doStep
            }
            // 给 PPT 页面切换动画留出时间，减少连续退页时丢页。
            handler.postDelayed({ runSteps(steps, i + 1, done) }, 600L)
        }
    }

    private fun toggleAuto() {
        if (auto) {
            stopAuto()
            toast("自动翻页已停止")
        } else {
            startAuto()
        }
    }

    private fun startAuto() {
        logic = AutoPagerLogic(
            Prefs.pageCount(this),
            Prefs.loopStyle(this) == Prefs.LOOP_RESTART
        )
        auto = true
        updateAutoButton()
        toast("自动翻页开始（请确认 PPT 在第 1 页）")
        handler.postDelayed(tick, Prefs.intervalSec(this) * 1000L)
    }

    private fun stopAuto() {
        auto = false
        handler.removeCallbacks(tick)
        updateAutoButton()
    }

    private fun updateAutoButton() {
        autoBtn?.text = if (auto) "停止" else "自动"
        autoBtn?.setTextColor(if (auto) Color.parseColor("#FF8A65") else Color.WHITE)
    }

    // ---------------------------------------------------------------- 小工具

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}
