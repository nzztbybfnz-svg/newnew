package com.pagepilot

import android.content.Context
import android.content.SharedPreferences

/** 用户设置，存在 SharedPreferences 里。 */
object Prefs {
    // 翻页方式
    const val MODE_VERTICAL = 0   // 上下滑动：上滑 = 下一页
    const val MODE_HORIZONTAL = 1 // 左右滑动：左滑 = 下一页
    const val MODE_TAP = 2        // 点击屏幕右侧 = 下一页，左侧 = 上一页

    // 自动翻页到最后一页之后
    const val LOOP_PINGPONG = 0   // 往返：倒着翻回第一页，再正着翻
    const val LOOP_RESTART = 1    // 快速退回第一页，再继续往后翻

    private fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("pagepilot", Context.MODE_PRIVATE)

    fun gestureMode(c: Context): Int = sp(c).getInt("gestureMode", MODE_VERTICAL).coerceIn(0, 2)
    fun setGestureMode(c: Context, v: Int) = sp(c).edit().putInt("gestureMode", v).apply()

    fun invert(c: Context): Boolean = sp(c).getBoolean("invert", false)
    fun setInvert(c: Context, v: Boolean) = sp(c).edit().putBoolean("invert", v).apply()

    fun intervalSec(c: Context): Int = sp(c).getInt("intervalSec", 5).coerceIn(1, 120)
    fun setIntervalSec(c: Context, v: Int) =
        sp(c).edit().putInt("intervalSec", v.coerceIn(1, 120)).apply()

    fun pageCount(c: Context): Int = sp(c).getInt("pageCount", 0).coerceIn(0, 999)
    fun setPageCount(c: Context, v: Int) =
        sp(c).edit().putInt("pageCount", v.coerceIn(0, 999)).apply()

    fun loopStyle(c: Context): Int = sp(c).getInt("loopStyle", LOOP_PINGPONG).coerceIn(0, 1)
    fun setLoopStyle(c: Context, v: Int) = sp(c).edit().putInt("loopStyle", v).apply()
}
